/*
 * fun.c
 *
 *  Created on: Jan 2, 2021
 *      Author: 99003164
 */

#include "main.h"
#include <fun.h>

uint16_t Ana_Rd(ADC_HandleTypeDef h_adc_1){
	uint16_t digital_variable;
	HAL_ADC_Start(&h_adc_1);
    if(HAL_ADC_PollForConversion(&h_adc_1, 5)== HAL_OK) {
    	digital_variable = HAL_ADC_GetValue(&h_adc_1);
    }
    return digital_variable;
}

void syst_beg(uint8_t fl){
	HAL_GPIO_WritePin(GPIO_LED_GPIO_Port, GPIO_LED_Pin, fl); }

